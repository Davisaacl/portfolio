/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cola;

/**
 *
 * @author edi
 */
public class Cola {
    
    // Cada vez que se supera el recorrimiento de 26, regresamnos al inicio
    // A = 65
    // A es congruente con 39 modulo 26
    
    public static String cifraMensajeCesar(String mensaje, ArrayQueue<Integer> llave){
        StringBuilder cad = new StringBuilder("");
        int aux = 0;
        int [] arregloLetras = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26};  
        
        for (int i=0;i<mensaje.length();i++){
            //aux = (int) (mensaje.charAt(i))-64;
            aux = mensaje.charAt(i) + llave.dequeue();
            cad.append(Integer.toString(aux));
        }
        return cad.toString();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int [] num = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26};
        ArrayQueue llave = new ArrayQueue<Integer>(); 
        
        llave.enqueue(17);
        llave.enqueue(6);
        llave.enqueue(25);
        llave.enqueue(-13);
        llave.enqueue(-8);
        llave.enqueue(4);
        
        //char pruebaAscii = 'A';
        
        //int prueba = (int) pruebaAscii;
        
        //System.out.println(prueba);
        
        //System.out.println("ITAM");
        
        String prueba2 = cifraMensajeCesar("ITAM", llave);
        
        
        
       
    }
    
}
